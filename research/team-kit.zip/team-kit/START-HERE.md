# START HERE — first 15 minutes in this repo (human + agent)

Work top to bottom. Everything with a slot gets your project's real values; humans fill them.

## 1. Clone & identity (once per person)

```bash
git clone <repo-url> && cd <repo>
git config user.email "<the email on YOUR account>"        # attribution is read from history
git config core.hooksPath scripts/git-hooks                # AI-trailer blocker + secret scan on commit
git config team.builder <your-name>                        # docs-mode B only; publish needs it
```

Install the secret scanner so the pre-commit hook can scan (optional but urged — without it,
commits only warn): `brew install gitleaks` / `winget install Gitleaks.Gitleaks`.

## 2. Give the agent its context

- Fill `PROJECT.md` (or run the `onboard` skill and approve every drafted line — never leave
  generated content unreviewed).
- Pick **Docs mode** in PROJECT.md (in-repo default, or the context-branch option) and delete the
  other checkbox.
- Docs-mode B only: `bash scripts/sync-context.sh` once, then set
  `git config team.doc-owner <name>` (values must match across the team).

## 3. First session with the agent

Say: *"fetch the context."* The agent should: read `PROJECT.md` and `AGENTS.md`, check
`BOARD.md` for open conflicts naming you, and summarize where things stand. If it doesn't, point
it at this file.

## 4. The habits that make it work

- One feature → one `ship`. Decisions → `decide` (yours to make, logged in `DECISIONS.md`).
- Check the board before starting; log every completed task on it; flag every possible collision.
- One agent per checkout — worktree/branch per parallel session.
- Wrapping up → `signoff`. New project or new teammate → this file, top to bottom.
