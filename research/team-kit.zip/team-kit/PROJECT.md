# PROJECT.md — the project's facts (the ONLY file a new team must fill)

Every `<!-- FILL -->` slot below is greppable: `grep -rn "FILL" PROJECT.md` shows what's missing
(the `scripts/init-kit.sh` doctor does the same). Humans fill these — an agent may *draft*
answers (skill: `onboard`) but a human approves every line before it counts; auto-generated
context left unedited measurably hurts. Facts win over AGENTS.md; process never does.

## One-liner
<!-- FILL: one sentence — what this project does and for whom -->

## People & ownership

| Who | Handle | Branch | Owns (paths / components) | Ask before touching |
|---|---|---|---|---|
| <!-- FILL --> | <!-- FILL --> | <!-- FILL --> | <!-- FILL --> | <!-- FILL --> |

**Shared (anyone edits; flag it in BOARD.md):** <!-- FILL: contracts/, fixtures/, compose files… -->

**Doc owner** (the one person who publishes shared docs others can't): <!-- FILL: name -->

## Commands (exact, with the flags that matter)

| What | Command |
|---|---|
| Install | <!-- FILL --> |
| Build | <!-- FILL --> |
| Test (with coverage) | <!-- FILL --> |
| Lint / typecheck | <!-- FILL --> |
| Run locally | <!-- FILL --> |
| Deploy | <!-- FILL: or "no deploy — local only" --> |

**Scale to design for:** <!-- FILL: e.g. "10k users, 1M rows, 50 req/s" — quality passes size for this -->

## Docs mode (pick ONE; delete the other)

- [ ] **In-repo (default):** shared docs live on `main`, changed by normal commits/PRs.
      `/publish` and the sync hook are no-ops. Simplest; docs are reviewable like code.
- [ ] **Context branch (public-repo option):** shared docs live on a separate branch, unpacked
      locally by `scripts/sync-context.sh` (never committed to main; `.gitignore` blocks it),
      published with `scripts/publish-context.sh`. Use when agent scaffolding must stay out of a
      public default branch. Machinery: `scripts/` + `scripts/context-docs.list` (battle-tested;
      sees only what you changed, refuses to clobber teammates' newer edits). Set once per clone:
      `git config team.builder <name>` · `git config team.doc-owner <name>` ·
      `git config team.context-branch <branch>`.

## Deploy target & environments
<!-- FILL: where it runs, how to reach it, what lives only there (secret PATHS, never values) -->

## Domain rules — never do / never say
<!-- FILL: hard invariants, compliance lines, pitch wording rules, "we tried X and it broke because Y" -->

## Locked decisions
<!-- FILL: decisions that need the team's named agreement to reopen (see DECISIONS.md for the log) -->

## Gotchas (one line each, added when learned)
<!-- FILL: start empty; add on every real failure (fail-driven) -->
