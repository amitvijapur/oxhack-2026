# Builder briefs (optional module)

Per-person task files, `builder-file-<name>.md`, one per teammate. **Optional**: small teams can
run on PROJECT.md §People + BOARD.md alone; add briefs when per-person task lists with
acceptance criteria earn their keep (distinct workstreams, uneven task sizes, async handoffs).
The doc owner writes and maintains briefs; each builder's agent makes exactly one self-edit —
moving its own finished task into Archived — and publishes it (docs-mode B) or commits it
(docs-mode A). Everything procedural lives in AGENTS.md and the skills, so a brief is pure
content: ownership + tasks + acceptance.

```markdown
# <Name>: <area one-liner>
**Handle:** `<github>` · **Branch:** `<name>-<area>` · **Updated:** <date> by <who>
Spec: PROJECT.md + AGENTS.md (the loop). Acceptance lines below are scorer criteria.

## Ownership
**Owns:** <paths / components — PROJECT.md §People is the summary; this is the detail>
**Does NOT touch:** <area — @owner> (shared: flag it in BOARD.md)

## ▶ Current tasks            ← the agent works top-to-bottom, only this block
- ⬜ **<task>** — <finished state + acceptance, concrete enough to score> `[⚠ conflicts with @name: what]`
- 🟡 <in-progress task, with the precise spot where it stopped>

## Done log
<✅ <task> — <date> (BOARD.md entry: <feature name>)>

── Archived (superseded <date> — do NOT action) ──
<superseded tasks move here, never deleted, with the reason>
```

Rules that make briefs work:

- **Acceptance lines are scorer criteria**: write "done" as something checkable (behaviour,
  metric, evidence file). Vague acceptance → vague gates.
- **One task, one ship**; if a task needs more than one `ship` run, it's two tasks.
- **Never reword or delete another builder's lines** — annotate next to them, or move superseded
  items to Archived with the reason. A change touching the seam between two builders goes in
  both briefs with the same interface note.
- **A conflict tag on a task is a stop sign**: talk to the named owner before starting it.
