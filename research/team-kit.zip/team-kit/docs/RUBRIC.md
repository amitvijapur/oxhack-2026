# Ship rubric (default)

The scorer agent grades every ship against this unless PROJECT.md or a brief adds stricter,
task-specific criteria (those **append** as additional critical items). Critical criteria are
marked **[C]** — any one failing, or being unverifiable, is a FAIL regardless of the rest.
Changing this file is a decision (`decide` skill): it is the team's definition of "done".

## Precondition: deterministic gates

**Build green · full test suite green · lint/typecheck green.** Exit codes are recorded and fed
to the scorer, which may re-run them. A red machine gate is an immediate FAIL — the rubric below
only governs what machines can't check.

## Intent & scope

1. **[C] Does what was asked** — the change implements the stated task completely; nothing
   deferred, stubbed, or silently dropped. Evidence: diff vs task text.
2. **No scope creep** — nothing lands that the task didn't ask for; refactors ride their own ship.

## Correctness

3. **[C] Behaviour is correct** — happy path, empty/null inputs, boundaries, and failure paths
   handled; no swallowed errors; error labels match what actually failed. Evidence: code read +
   tests.
4. **[C] Tests prove it** — new/changed behaviour has tests (happy, edge, failure); the full
   suite is green; coverage of the changed code is meaningful. Reverting the diff would fail at
   least one test. **No test was deleted, skipped, or weakened to get here** — the scorer's
   tamper check greps the diff for exactly this; it is a FAIL with the quoted lines.
5. **Contracts intact** — public interfaces, schemas, event formats, API shapes unchanged, or
   changed only per an agreed contract update; callers and teammates' assumptions from
   PROJECT.md/briefs still hold.

## Craft

6. **No slop** — a quality pass ran and its findings are fixed: no dead code, no what-comments,
   no duplicated logic, no over-defensive checks, right complexity class for the scale in
   PROJECT.md.
7. **Style fits** — naming, error style and structure read like the surrounding codebase;
   comments explain WHY only.

## Team & safety

8. **[C] No secrets, no leaks** — no credentials, tokens, keys, personal data, or anything that
   must stay out of the repo, in the diff or its logs.
9. **Conflicts flagged** — every touched file checked against PROJECT.md §People ownership; each
   possible collision named in the BOARD.md entry (⚠️ Conflicts), not discovered later by its
   victim.
10. **Honest evidence trail** — the BOARD.md entry states what actually shipped (including
    limitations); its claims are backed by the diff and test output, not aspiration.

## Notes for the scorer

- Grade against evidence you can open and re-run. Anything unverifiable → `unknown`; `unknown`
  on a [C] criterion is a FAIL.
- Every quoted span must string-match the artifact exactly. A non-matching quote fails that
  criterion and is flagged as hallucinated evidence.
- The author's confidence is not evidence.
