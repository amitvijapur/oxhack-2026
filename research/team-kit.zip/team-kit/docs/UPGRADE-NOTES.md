# UPGRADE-NOTES — from the original (v1) to this kit, and the evidence for every change

v1 is the system a real 4-person team ran during a 24-hour IBM Z Datathon (event-tested; a
1026-line conflict board and a mid-event publish-clobber bug found, fixed and regression-tested
prove it). This kit keeps what survived contact with reality and rebuilds the rest against
late-2026 evidence gathered from a wide source mix — official Claude Code docs and the AGENTS.md
standard, Anthropic engineering posts, arXiv studies, engineering blogs, and practitioner signal
from Reddit, X, HN and forums. Each numbered change names its basis; contested calls say so.

## 1. Charter split: AGENTS.md (universal contract) + thin CLAUDE.md shim + PROJECT.md (facts)

- **Basis:** AGENTS.md became the vendor-neutral standard (Linux-Foundation-backed, 60k+ repos;
  Claude Code reads it natively or via `@AGENTS.md` import) — a kit keyed to one vendor's file
  bakes in lock-in. The strongest parameterization evidence is the ETH Zurich AGENTS.md
  evaluation: human-written context files +~4% task success while **LLM-generated files cost
  +20–23% inference and slightly reduce success** — hence greppable `<!-- FILL -->` slots filled
  (or at least approved) by humans, with the `onboard` skill limited to drafting. A curated
  three-paper synthesis puts the universal/project split exactly here: workflow contract vs
  facts file. v1 had the right instinct (its "Project Registry, fill as you learn") embedded in
  a 410-line vendor-specific charter.
- **Change:** process rules → `AGENTS.md` (~120 lines, vendor-neutral); project facts →
  `PROJECT.md` slots; Claude-specific wiring → a 19-line shim. Leanness targets stay (official
  best practice: bloated charter files get ignored), but the deeper finding from a 1,650-session
  study is that **presence + deterministic enforcement** matters far more than length in the
  25–500-line band — so we stopped optimizing line count and moved every must-hold rule into
  hooks/CI (see §4).

## 2. Procedures moved to skills (procedures as skills, evidence-backed)

- **Basis:** official skills model — metadata always in context (~100 tokens/skill), bodies
  load on demand; multi-step procedures belong in skills, not always-on charter text. v1 carried
  the full ship sequence, sign-off protocol and research protocol inline, duplicated again in
  all four briefs.
- **Change:** the procedures became skills (`ship`, `score`, `decide`, `signoff`, `conflicts`,
  `research`, `sync`, `publish`, `onboard`), each with trigger-style descriptions. Briefs
  dropped their boilerplate (now an optional module, pure content).

## 3. Docs mode: in-repo by default; the context branch demoted to an optional module

- **Basis (contested → resolved):** v1's `context` branch (shared agent docs on a separate git
  branch, unpacked by script) has **no prior art found anywhere** in the ecosystem — broad
  research across docs, blogs, Reddit/X/HN surfaced nobody else doing it, and the field's
  converged default is committed docs changed through review (the Claude Code creator's own team
  routes CLAUDE.md changes through PRs). The pattern's real costs: doc changes invisible in
  normal diffs, sync-script drift, one more thing to learn before the first prompt works. Its
  real strength: it solved an actual problem for a public repo during a live event, and the
  machinery is unusually well hardened (clobber-proof publish, backup-on-sync, ownership +
  credential guards, a regression harness replaying the real mid-event failure).
- **Change:** docs-mode **A (in-repo) is the default**; mode B survives as an optional module
  for public repos, config-driven (`git config team.*`), its scripts genericized (tracked-doc
  list in `scripts/context-docs.list`, no hardcoded names — the test harness now proves it with
  completely different people/branch/docs) and its hooks arm only when configured.

## 4. Enforcement: fewer hooks, fail-closed, off the prompt path

- **Basis:** "a context file is a suggestion; a linter/hook is a wall" is now community
  consensus (top-rated practitioner advice; agents ignore prose under pressure). But hooks have
  a documented failure catalog: UserPromptSubmit hooks block the prompt with a 30 s ceiling
  (wrong place for network/git I/O); non-exit-2 hooks fail open; unseen failures degrade
  silently; practitioners with 95-hook histories converged on "start with ~3". v1's sync rule
  was prose (model compliance) — its own mid-event incident log shows compliance being policed
  by hand.
- **Change:** three hooks, each mapped to a real v1 failure: doc guard (PreToolUse, exit 2 +
  `onFailure: block` — fail-closed), session-start sync (SessionStart, not UserPromptSubmit —
  no network on the prompt path; `onFailure: continue` since a missed sync degrades, not
  endangers), publish reminder (Stop — the single most-forgotten v1 rule). Settings ship
  permission denies for secrets/env reads and history-destroying git commands.

## 5. The scorer gate — kept (it's the point), hardened (it was the weakest link)

- **Basis (the sharpest finding of the whole research pass):** fresh-context review genuinely
  catches bugs (a controlled study: review passes raised a weak writer's pass rate 71.6%→89.7%),
  **but same-family self-review was a statistical no-op**, and rubric scores can be beautiful
  and wrong (a 9.3/10 process rubric alongside a 44% test pass rate). Judge-bias research
  (self-preference, hallucinated citations) says an unhardened LLM gate is a rubber stamp with
  extra steps. Anthropic's own productized review **never blocks merges** and filters reviewer
  false positives with a verification stage.
- **Change — the gate stays (a human decision for this kit), but its evidence contract changed:**
  deterministic gates (build/test/lint exit codes) run **first** and a red gate is auto-FAIL —
  the rubric only governs what code can't check; every quoted evidence span must string-match
  the artifact (non-matching quote = failed criterion, flagged as hallucinated); a tamper check
  greps the diff for deleted/weakened tests and edits to verifier files; cross-family scorer
  model recommended where the host allows; iteration cap 3 **plus** an early stop on repeated
  identical failure (non-convergence) and a spend note. The rubric gained the precondition
  section and the tamper veto.

## 6. Board kept (append-only), briefs demoted to optional, ownership kept

- **Basis (contested):** simulation research says coordination files on top of git coordination
  *lowered* output quality, and hand-maintained boards rot. But git-as-coordination is exactly
  what scaled in the 16-agent C-compiler build (file-lock claims, shared bare repo), and v1's
  board demonstrably worked for a real team — it caught real cross-person breakages (a
  publish-clobber, a 502 traced to a header buffer, an Elexon 0 Hz bug) because it is
  **append-only with named conflict ownership**, which is the durable form. Per-person briefs
  have no ecosystem prior art beyond CLAUDE.local.md-style personal context; they earned their
  keep in v1 mainly as task lists, which collapse into PROJECT.md ownership + the board for
  most teams.
- **Change:** `BOARD.md` kept as the append-only ship log + conflict board, volatile facts in
  exactly one place (its Current-state block). Ownership table kept in PROJECT.md and treated
  as the seam map. Briefs: optional module (`docs/brief-template.md`), no boilerplate.

## 7. Loop hardening: plan-first and one-agent-per-checkout made explicit

- **Basis:** the ecosystem's biggest late-2026 lever is a gate **before** work (plan mode —
  credited by practitioners for unsupervised parallel runs), and "two agents in one checkout is
  silent last-write-wins data loss" is universal field experience; native worktrees are the
  standard answer.
- **Change:** the loop in AGENTS.md now has an explicit plan-nod step before code, and a
  parallel-work section (worktree per session/branch, frequent main-merges, shared-resource
  discipline).

## 8. Everything carried forward unchanged from v1

The 8 quality/UI skills (`no-slop`, `debug`, `design-direction`, `frontend-performance`,
`motion`, `motion-review`, `reverse-engineer-ui`, `ui-audit` + shared `references/`) — their
descriptions, progressive disclosure and scripts were already best-practice; unchanged. The
git hooks (commit-msg AI-trailer blocker, pre-commit secret scan). The context-branch scripts'
core algorithms (changed-set = mine≠base ∧ mine≠remote; backup-before-overwrite;
MSYS_NO_PATHCONV) — genericized, not redesigned, and still covered by a scenario-replay test
harness.

## Source trail (selection)

Official: Claude Code best-practices / skills / hooks / subagents / worktrees / memory docs;
AGENTS.md standard. Engineering: Anthropic multi-agent research system, agent-skills post,
C-compiler swarm, Outcome grader cookbook, "demystifying evals". Research: ETH Zurich AGENTS.md
evaluation (LLM-generated context harms), cross-model review study arXiv 2607.21656 (same-family
self-review no-op), MT-Bench/judge-bias literature, 1,650-session CLAUDE.md compliance study.
Practitioner: r/ClaudeCode + r/ClaudeAI team threads (source-diverse), HN maintaining-CLAUDE.md
and hook-failure threads, incident.io worktrees, agent-work-board post-mortem, 95-hook
governance writeup. Full ledger: `docs/RESEARCH-LEDGER.md` in the handover package (provenance only — not installed into target repos by init-kit.sh).
