# BOARD — ship log & conflict board (append-only)

Newest at the bottom. Every completed task gets an entry the same turn it lands, pushed to main.
Anyone named in an open ⚠️ resolves (or agrees a fix with the flagger) before touching that area,
then flips the status. Never rewrite or delete another person's entries.

```
### <YYYY-MM-DD HH:MM> — <feature> — @<owner>
- Shipped: <what changed, why>
- Touched: <files / modules / endpoints / shared contracts>
- ⚠️ Conflicts: @<Name> — <what of theirs this changes or could break> | none
- Conflict status: open | resolved by @<Name> <date>
- 📨 To <Name>: <what they must do before/after this lands>   (only when someone else owes an action)
```

## Current state
<!-- The single source of volatile facts: what's live, current test counts, anything "as of".
     Update this block with every entry; everything else links here, never re-states it. -->

- As of <!-- FILL -->: <!-- FILL -->

---
<!-- entries below, newest last -->
