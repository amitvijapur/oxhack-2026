@AGENTS.md

# Claude Code specifics

The contract above is vendor-neutral (AGENTS.md, the Linux-Foundation-backed standard every
coding agent reads). Everything below is Claude Code wiring only.

- **Skills** load on demand; their one-line descriptions are always in context. Trigger phrases
  are in each description. Key ones: `ship`, `score`, `decide`, `conflicts`, `research`, `sync`,
  `publish`, `signoff`, `onboard`, `no-slop`, `debug` (+ the UI family: `design-direction`,
  `motion`, `motion-review`, `ui-audit`, `frontend-performance`, `reverse-engineer-ui` for
  frontend work).
- **Subagents** (`.claude/agents/`): `scorer` (fresh-context grader), `reviewer` (adversarial diff
  review), `researcher` (web research with sourcing discipline). Spawn — don't grade your own
  work in-context.
- **Hooks** (`.claude/settings.json`): shared-doc guard (PreToolUse, blocking), doc-sync
  (SessionStart), publish reminder (Stop). They are deterministic; this file is advisory.
- **Settings**: `.claude/settings.json` is shared; personal overrides go in
  `.claude/settings.local.json` (gitignored) or `CLAUDE.local.md` — never in shared files.
