# Team Workflow Kit — any project, any team of 3–10, every member running a coding agent

A drop-in workflow system for teams where **each developer runs their own agent session against
one shared repo**. Born from a real 4-person team's battle-tested system (see
`../v1-original/EXTRACTED-INVENTORY.md` for the original), then rebuilt against late-2026
research: official Claude Code docs and the AGENTS.md standard, engineering-blog practice, and
practitioner signal from Reddit/X/HN/forums. Design choices and their evidence:
`docs/UPGRADE-NOTES.md`.

## Install (one command)

```bash
bash /path/to/team-kit/scripts/init-kit.sh /path/to/your-repo
```

Idempotent — adds only what's missing, never overwrites. Then a **human** fills the `<!-- FILL
-->` slots in `PROJECT.md` (the `onboard` skill can draft them; approval required). Ready when
`grep -rn "FILL" PROJECT.md` returns nothing.

## What's in it

| Path | What |
|---|---|
| `AGENTS.md` | **The contract** — vendor-neutral rules that hold every prompt (loop, gates, board protocol, decision ownership). Read by every coding agent that speaks the AGENTS.md standard |
| `CLAUDE.md` | Thin Claude Code shim (`@AGENTS.md` + wiring notes) |
| `PROJECT.md` | **The only file a new team must fill** — people/ownership, exact commands, docs mode, deploy, domain rules, locked decisions, gotchas. Greppable `<!-- FILL -->` slots |
| `BOARD.md` | Append-only ship log + conflict board; volatile facts live only in its Current-state block |
| `DECISIONS.md` | Lightweight ADR log + Unconfirmed parking lot |
| `START-HERE.md` | First-15-minutes onboarding for a new teammate |
| `.claude/settings.json` | Three hooks (fail-closed where it matters) + permission denies (secrets, force-push) |
| `.claude/hooks/` | Doc guard (PreToolUse, docs-mode B), session-start sync, publish reminder (Stop) |
| `.claude/skills/` | Workflow: `ship`, `score`, `decide`, `conflicts`, `research`, `onboard`, `sync`, `publish`, `signoff` · Quality/UI: `no-slop`, `debug`, `design-direction`, `motion`, `motion-review`, `ui-audit`, `frontend-performance`, `reverse-engineer-ui` (+ shared `references/`) |
| `.claude/agents/` | `scorer` (fresh-context rubric grader), `reviewer` (adversarial diff review), `researcher` (web research with a source ledger) |
| `docs/RUBRIC.md` | The ship rubric — deterministic gates first, 10 criteria, criticals marked |
| `docs/brief-template.md` | Optional per-person brief module |
| `scripts/init-kit.sh` | Idempotent installer + unfilled-slot doctor |
| `scripts/{sync,publish,test}-context*`, `context-docs.list` | **Optional docs-mode B** (context branch) — battle-tested unpack/publish machinery for public repos |
| `scripts/git-hooks/` | commit-msg (no AI trailers) + pre-commit (secret scan) |

## The two docs modes (pick in PROJECT.md)

- **A — in-repo (default):** shared docs are ordinary repo files on `main`, changed by commits
  and PRs like code. Simplest; doc changes are reviewable; the sync hooks no-op.
- **B — context branch (public-repo option):** shared docs live on a separate git branch,
  unpacked locally by script, never committed to `main`. Same machinery the original team ran
  through a 24-hour event (clobber-proof publish, backup-on-sync, ownership + credential
  guards). Heavier — only worth it when agent scaffolding must stay out of a public default
  branch.

## The shape of a working day

Check the board → plan → decide (humans own design decisions) → `ship` (quality pass → tests →
deterministic gates → **scorer PASS** → branch → merge → board entry) → log. One feature per
ship. One agent per checkout (worktrees for parallel sessions). Wrapping up → `signoff`.

(`PROJECT.md` is the only file to fill upfront — BOARD.md's single Current-state line fills in with your first entry.)

**The one behavior change to internalize:** nothing merges on the author's own say-so — green
machine gates **and** a fresh-context scorer PASS with verifiable evidence, every time.

## Porting notes

The kit is stack-agnostic (no language assumptions; scale/design targets are slots). For a
**private** repo, default to docs-mode A and skip `scripts/*context*`. For a **public** repo,
mode B keeps the working tree clean for judges/outsiders. Personal preferences never go in
shared files — `CLAUDE.local.md` / `.claude/settings.local.json`. If your team grows past ~10 or
spans many repos, package the survivors as a plugin marketplace instead of copying folders.
