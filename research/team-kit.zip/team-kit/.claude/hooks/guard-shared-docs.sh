#!/bin/sh
# PreToolUse hook (Bash): in docs-mode B (context branch), shared docs must never be staged or
# committed to `main`. .gitignore already ignores them there, so the only way in is an explicit
# path or -f — this hook blocks that before git ever runs. Armed only when docs-mode B is on:
# `git config team.context-branch <branch>` is set (see START-HERE step 1). In docs-mode A
# (docs in-repo, the default) the hook is inert — committing these files is legitimate there.
# Fail-closed via "onFailure": "block" in settings.json. Exit 2 = blocking; stderr is the reason.
# Never blocks reads. The tracked set beyond these well-known names lives in
# scripts/context-docs.list; .claude/** is guarded wholesale since it rides the branch too.
input=$(cat)
branch=$(git -C "$CLAUDE_PROJECT_DIR" config --get team.context-branch 2>/dev/null)
[ -n "$branch" ] || exit 0
case "$input" in
  *git\ add*|*git\ rm*|*git\ mv*|*git\ commit*)
    # a shared doc named inside a staging/commit-path command
    case "$input" in
      *CLAUDE.md*|*AGENTS.md*|*PROJECT.md*|*BOARD.md*|*DECISIONS.md*|*START-HERE.md*|*CONTEXT-README.md*|*builder-file-*|*.claude/*|*.claude\\*)
        echo "blocked: shared docs (CLAUDE.md, AGENTS.md, PROJECT.md, BOARD.md, DECISIONS.md, START-HERE.md, briefs, .claude/) live on the '$branch' branch in docs-mode B, never on main. Publish with /publish instead; see AGENTS.md and PROJECT.md §Docs mode." >&2
        exit 2
        ;;
    esac
    ;;
esac
exit 0
