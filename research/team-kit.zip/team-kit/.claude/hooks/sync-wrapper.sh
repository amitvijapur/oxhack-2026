#!/bin/bash
# SessionStart hook: re-sync shared docs from the `context` branch when a session begins, so no
# session starts from a stale vision. Deterministic (AGENTS.md is advisory; hooks are walls) but
# never blocking: offline or a missing branch degrades to one line. Syncing at session start —
# not per prompt — keeps network I/O off the prompt path (UserPromptSubmit hooks have a 30 s
# ceiling and stall the prompt). Docs-mode A (in-repo docs): sync prints its no-op line and
# nothing is surfaced. /sync forces it by hand mid-session.
out=$( { bash "$CLAUDE_PROJECT_DIR/scripts/sync-context.sh" 2>&1 || echo "context: sync failed (offline? branch missing?) — continuing on the local copy"; } )
# Surface only actionable lines; suppress the routine "up to date"/no-op cases entirely.
echo "$out" | grep -E 'UPDATED|first sync|unpublished edits|sync failed|saved in' || true
exit 0
