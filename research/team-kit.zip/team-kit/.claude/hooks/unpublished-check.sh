#!/bin/sh
# Stop hook: if the turn edited a shared doc but it wasn't published to the context branch,
# remind (never block). Without this, a teammate's next sync silently misses the edit — the
# "publish same turn" rule is the one step models most often forget at end of turn.
# The tracked set: every path on the last-synced context commit, plus scripts/context-docs.list
# (globs allowed there, but not in paths containing spaces). No stamp yet = nothing to check.
cd "$CLAUDE_PROJECT_DIR" 2>/dev/null || exit 0
gitdir=$(git rev-parse --git-dir 2>/dev/null) || exit 0
stamp=$(cat "$gitdir/context-synced" 2>/dev/null) || exit 0
[ -n "$stamp" ] || exit 0

tmp=$(mktemp) || exit 0
# everything the last sync knew about (exact paths, spaces safe)
git ls-tree -r --name-only "$stamp" 2>/dev/null >> "$tmp"
# plus the tracked list (globs expand; a glob must not contain spaces)
if [ -f scripts/context-docs.list ]; then
  while IFS= read -r entry; do
    case "$entry" in ''|'#'*) continue ;; esac
    case "$entry" in
      *\?*|*\**|*\[*) for g in $entry; do [ -e "$g" ] && printf '%s\n' "$g" >> "$tmp"; done ;;
      *) printf '%s\n' "$entry" >> "$tmp" ;;
    esac
  done < scripts/context-docs.list
fi

changed=""
sort -u "$tmp" | while IFS= read -r f; do
  [ -f "$f" ] || continue
  mine=$(git hash-object "$f" 2>/dev/null) || continue
  base=$(git rev-parse -q --verify "$stamp:$f" 2>/dev/null || echo none)
  [ "$mine" = "$base" ] || printf '%s\n' "$f"
done > "$tmp.changed"

if [ -s "$tmp.changed" ]; then
  changed=$(tr '\n' ' ' < "$tmp.changed")
  printf '{"systemMessage": "Shared docs edited but not published to the context branch: %s. Run /publish \\"what changed\\" before ending the turn, or the edit will not reach teammates."}\n' "$changed"
fi
rm -f "$tmp" "$tmp.changed"
exit 0
