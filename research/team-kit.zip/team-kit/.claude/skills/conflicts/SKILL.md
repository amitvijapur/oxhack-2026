---
name: conflicts
description: Check the BOARD.md conflict board for new entries and open conflicts naming the current human - run at the start of work on any shared area, before merging, when the user says "check the board", "any conflicts?", "what landed while I was away", or when about to touch a teammate's owned area. Also writes the conflict-board entry after a ship.
---

# Conflict board — read before acting, write after shipping

## Read pass (new entries only; don't reread the whole file)

```!
cd "$CLAUDE_PROJECT_DIR" && git fetch -q origin main 2>/dev/null; git diff HEAD..origin/main -- BOARD.md 2>/dev/null | head -300 || echo "offline — read the newest local entries instead and say the check was local-only"
```

1. From the diff above, list what landed since this clone last checked.
2. **Open conflicts naming the current human** (`⚠️ Conflicts: @<name>` with status `open`):
   - Tell the user first, in one line: who flagged what.
   - If the current task touches that area, resolve before continuing (adapt, or agree a fix with
     the flagger), then flip the entry to `resolved by @<user> <date>`.
   - Adjacent but not colliding? Say so and suggest the safe ordering. Never start overlapping
     work silently.
3. Cross-check the task at hand against the ownership table in `PROJECT.md` §People: touching
   someone's **owns** list → their sign-off first, or flag them in your entry.

## Write pass (after a ship — normally from the `ship` skill)

Append (newest last) and push to `main` in the same turn — format in AGENTS.md §BOARD.md:

```
### <YYYY-MM-DD HH:MM> — <feature> — @<owner>
- Shipped: <one or two lines: what changed, why>
- Touched: <files / modules / endpoints / shared contracts>
- ⚠️ Conflicts: @<Name> — <what of theirs this changes or could break> | none
- Conflict status: open | resolved by @<Name> <date>
```

Rules: every completed task gets an entry — not just merges (deploys, fixes, decisions that
change work). A *possible* collision counts as a conflict. Cross-person requests live here or in
the named brief — never only in chat. Never rewrite or delete another person's entries; annotate
or mark resolved. Update the **Current state** block at the top when volatile facts changed.
