---
name: decide
description: Surface a design decision to the user with options, trade-offs and a recommendation, then wait - use whenever a task contains a choice a real software engineer would pause on (data and storage, API contracts, trust boundaries, where compute runs, failure modes, dependencies, correctness/speed/cost trade-offs, anything touching a locked decision), when the user says "decide", "should we X or Y", or when unsure whether a choice is the user's to make. Err toward handing off; silent choices are the failure mode.
argument-hint: "[one-line name of the decision]"
---

# Decide — the human owns it, the agent proposes

## The handoff format (exact)

> **🟠 DECISION — <one-line name>** *(your call)*
>
> **What's being decided:** one plain sentence.
>
> **Options:**
> - **A — <name>:** what it is · ✅ upside · ⚠️ cost/risk
> - **B — <name>:** what it is · ✅ upside · ⚠️ cost/risk
> - *(2–4 realistic options; no strawmen)*
>
> **My recommendation:** X, because … (tie it to the research ledger, a project gotcha in
> PROJECT.md, or a concrete failure mode)
>
> **What I need from you:** pick A/B/…, or say "you decide" to hand it back.

Keep the ask clean — headed structure, short bullets, whitespace. Several decisions = separate,
clearly-titled blocks in a queue so the user can scan and pick each in turn. Teaching depth is
Level 0 by default (AGENTS.md); the user can ask for the "what this entails" note per decision.

## Then STOP and wait

No implementation until the human picks. Not even the parts "everyone would want" — a partial
implementation presumes the decision.

## When they pick

1. Log it in `DECISIONS.md` (append-only):
   `## <date> — <name>` / `Chose: <option> (<who>)` / `Because:` / `Rejected:` / `Revisit if:`
2. Attribute by person; unnamed → "(owner: TBC)". Never invent an owner.
3. Future options surfaced in the handoff ("for now X, later maybe Y") go under
   *Unconfirmed / yet-to-confirm* — parked, never treated as agreed.
4. If ownership, scope or who-does-what changed: update `PROJECT.md` §People and the affected
   brief, and publish doc edits per PROJECT.md §Docs mode.
5. If it reopens a **locked** decision (PROJECT.md §Locked decisions): it needs the team's named
   agreement and the human's explicit approval first — say so in the handoff.

## What is NOT a handoff

Bugs with one correct answer, zero-behaviour refactors, implementing a decision already made,
tests for existing behaviour, formatting — just do those and say what you did in one line.
Unsure which bucket → hand off anyway.
