---
name: sync
description: Manually pull the latest shared team docs from the context branch and report what changed - run when the user says "sync", "pull the context", "what changed on context", when shared docs look stale mid-session, or after the SessionStart hook reports a problem. Docs-mode A (in-repo docs): this is a no-op — say so and move on.
---

# Sync shared context (docs-mode B only)

```!
cd "$CLAUDE_PROJECT_DIR" && bash scripts/sync-context.sh 2>&1 || echo "sync failed — offline or branch missing; continuing on the local copy"
```

Then:

1. It printed the **no context branch** line → docs-mode A: docs are committed in-repo; a plain
   `git pull` is the sync. Say so in one line and stop.
2. It printed **UPDATED** (or first sync): read `PROJECT.md` and the current human's brief, then
   summarise what changed for the user in 1–2 lines **before** doing anything else. If
   `AGENTS.md` changed, re-read it in full and follow the new version.
3. It saved unpublished local edits to `.git/context-backup/<timestamp>/`: tell the user which
   files, re-apply their edit on top of the incoming version (keeping every incoming line), then
   `/publish`.
4. Up to date → one line, get on with the task.

Never commit the synced files: they are git-ignored on `main` on purpose in this mode, and the
PreToolUse guard blocks staging them.
