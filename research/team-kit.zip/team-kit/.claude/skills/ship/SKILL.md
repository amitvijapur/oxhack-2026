---
name: ship
description: The mandatory end-to-end ship sequence for any completed feature, fix or task - run it when a piece of work is done and ready to land, when the user says "ship it", "land this", "merge this", or before any push, PR or merge. Chains the gates in order (no-slop pass, tests with coverage, deterministic build/test/lint green, fresh-context scorer PASS, branch push, main-merge with retest) and writes the BOARD.md conflict-board entry. Nothing reaches main without green deterministic gates AND a scorer PASS.
argument-hint: "[one-line description of what is shipping]"
allowed-tools: Bash(git *), Bash(pytest*), Bash(npm *), Read, Edit, Grep, Glob
---

# Ship

One feature, one ship. The order is the gate — each step refuses to continue on failure. Never
batch several features into one ship. $ARGUMENTS

## 0. Pre-flight (say no and stop if any fails)

- The work is **one** feature/task, complete (no TODOs hiding scope), and it followed the loop in
  AGENTS.md: plan made and nodded, design decisions handed off (`decide`) and disposed.
- Commands known: PROJECT.md §Commands (test/lint/build). Branch: PROJECT.md §People (or
  `<name>-<area>` per the ownership table).
- No open ⚠️ on `BOARD.md` naming the current human in the touched area (`conflicts` skill). If
  there is one, resolve or agree with the flagger first.

## 1. no-slop pass

Run the `no-slop` skill (or the repo's quality-pass equivalent) on the finished diff. Fix
everything it finds (it flags design decisions instead of changing them).

## 2. Tests with coverage

Write or extend tests for the change: happy path, edge cases, failure paths. Run PROJECT.md's
test command with coverage. The changed code must be well covered and the whole suite green.
**Do not weaken, skip, or delete existing tests to get here** — the scorer checks for it, and
weakening a test to pass is treated as tampering with the gate.

## 3. Deterministic gates green

Run the build, the full test suite, and lint/typecheck — **exit codes are recorded and become
scorer input**. Any red → fix before the scorer runs; a rubric PASS over a red build is
meaningless and the scorer will veto it.

## 4. Fresh-context scorer verdict (the gate)

Dispatch the `scorer` subagent with: the diff/files, the stated intent, `docs/RUBRIC.md` plus any
acceptance criteria from PROJECT.md/briefs, and the exit-code evidence from step 3. It returns a
JSON verdict. **Only a PASS continues.** On FAIL: fix every cited gap, then re-run steps 1–4. Do
not soften, relitigate, or re-grade the verdict yourself — the scorer's verdict is the gate, not
an opinion. If the host allows choosing the scorer's model, prefer a **different model family**
than the session's (same-family self-grading is the weakest configuration). Max 3 revision
rounds; still failing → stop, surface the verdicts and gaps to the human (ship anyway / rework /
re-scope is their call). Two consecutive rounds with the *same* top gap = stop early: that's
non-convergence, not a polishing problem.

## 5. Branch push

Commit as the human (plain message, no AI trailer — the commit-msg hook rejects it; if it fires,
remove the trailer, never bypass the hook). Push to the feature/owner branch, never straight to
`main`.

## 6. Merge origin/main, retest

`git merge origin/main` into the branch, re-run the tests. Conflicts: fix on the branch — if
it's a teammate's code, agree the fix per the board before going further.

## 7. Merge to main, log the ship

Merge into `main` and push. Append the `BOARD.md` entry (format in AGENTS.md) in the same turn:
Shipped / Touched / ⚠️ Conflicts (checked against PROJECT.md §People ownership; a *possible*
collision counts) / status. Update `BOARD.md` → Current state if volatile facts changed. Publish
doc edits per PROJECT.md §Docs mode — same turn.
