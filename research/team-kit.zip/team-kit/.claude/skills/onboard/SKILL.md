---
name: onboard
description: Bootstrap a new project or re-verify an existing one against the kit - run when setting up this workflow in a new repo, when the user says "onboard this project", "set up the workflow", "fill in PROJECT.md", "what slots are unfilled", or when PROJECT.md still contains FILL markers and work is starting. Scans the repo, interviews the human, DRAFTS slot answers for approval, and runs the unfilled-slot doctor. A human approves every drafted line; unedited generated context measurably hurts.
argument-hint: "[new | doctor]"
---

# Onboard — fill the kit with THIS project

Two modes: `$ARGUMENTS` = `doctor` (or PROJECT.md has no FILL markers) → just run the doctor.
Otherwise, full bootstrap.

## 1. Doctor (always available, always safe)

```!
cd "$CLAUDE_PROJECT_DIR" && echo "unfilled slots:" && grep -rn "FILL" PROJECT.md START-HERE.md BOARD.md 2>/dev/null | wc -l && grep -rn "FILL" PROJECT.md START-HERE.md BOARD.md 2>/dev/null || echo "none — kit is fully filled"
```

Any `<!-- FILL -->` marker found → list them for the human; work that depends on a slot must not
start until that slot is human-approved.

## 2. Scan (read-only, no edits yet)

Inventory the repo: language/framework/build tooling (package manifests, lockfiles, CI configs),
test runner + how to run it, lint config, existing docs/README claims, deploy hints, git branch
conventions. Note what contradicts the README (the README sells; the manifests are the truth).

## 3. Interview (the human answers; you don't guess)

Ask, in one batch, only what the scan couldn't answer: the one-liner, the people/ownership table
(names, handles, branches, owns), scale to design for, docs mode (A in-repo default, or B
context-branch for public repos — explain the trade-off in two lines), deploy target, domain
never-do rules, and anything locked. Short answers are fine ("ask @X later" fills a TBC slot).

## 4. Draft slots — then STOP for approval

Fill every `<!-- FILL -->` slot with drafted text from scan + interview, clearly marked as
drafts. **A human approves every line before it counts.** If a slot can't be drafted (nobody
knows yet), leave the FILL marker — an honest empty slot beats invented content. Never fabricate
commands: a wrong build command in PROJECT.md is worse than none.

## 5. After approval

- Run the doctor again: zero FILL markers in PROJECT.md (TBC slots may remain, named).
- Docs-mode B: set the three `git config team.*` values, run `scripts/sync-context.sh` once,
  create the context branch from the current docs, verify `scripts/test-context-scripts.sh`
  still passes.
- Kick the tires: one tiny real task through `ship` end-to-end, including a scorer round.
  Fix what felt wrong BEFORE the team adopts the kit.
