---
name: research
description: Evidence-first research protocol with a per-source verdict ledger - use for ANY research, asked ("look this up", "validate this", "is X true") or self-initiated (a subagent spun up to check something), before citing any external claim, number, library choice or benchmark, and when the user says "research", "find sources", "what's the best X". Sources span official docs, papers, engineering blogs, Reddit, X, forums, news. One pass gathers sources AND grades them AND saves the ledger; findings without a ledger are not a deliverable.
argument-hint: "<question or topic>"
---

# Research — verify, corroborate, ledger

$ARGUMENTS

## Sourcing rules

- **Wide source mix**: official docs and standards, peer-reviewed papers, engineering blogs of
  the actual builders, GitHub repos/issues/changelogs — **and** practitioner signal from Reddit,
  X/Twitter, HN, forums, news coverage. The first group gives the professional consensus; the
  second gives the community consensus. Weigh professional sources for facts, community sources
  for lived experience and failure modes; keep the two labelled separately.
- **Recency**: last 1–2 years preferred; 3–4 only when recent high-quality work is scarce (say
  so). Anything older needs a reason it's still authoritative.
- **Verify existence before citing.** Fetch the actual source. Never cite from memory or a bare
  ID. A URL you haven't opened is not a source; a search snippet is not a source.
- **Consensus**: every load-bearing claim or metric needs **≥2 independent corroborating
  sources**. Two posts quoting the same original count as one — find the original.
- **Hunt refutations deliberately**: for each strong claim, one search on why it might be wrong
  ("X broken", "X deprecated", "X vs Y", "X ignored"). Multiple credible refutations → the claim
  is DO NOT USE, the disproving sources named.

## The ledger (mandatory, same pass)

Grade every source and append the section to the research doc (`docs/research.md`; create on
first use) before reporting findings:

- **KEEP** — corroborated (name the corroborating sources)
- **WEAK** — thin support, single-source, or caveated
- **DO NOT USE** — refuted (name the disproving sources); quarantined at the bottom of its
  section with a tombstone so it isn't re-litigated; its metrics stripped from active use.

Structure: one file, one labelled section per pass, category index updated, KEEP entries at the
top. If sources refute a claim the team has been using, say so loudly **and** flag where the
claim was used. Publish per PROJECT.md §Docs mode.

## The report

Verdict per question: professional consensus + community consensus, both named, then the
aggregate. Cite by ledger section. Where sources disagree, say which way the weight falls and
why. Low confidence is a valid answer — never pad.

## Efficiency

Wide topic → fan out parallel `researcher` subagents, one per sub-question, each with a precise
scope, expected output shape, and told which adjacent topics belong to other agents (vague
scopes overlap). Then one cross-check pass to dedupe and grade. Fan-out costs ~4–15× a single
pass in tokens — use it for load-bearing questions, not quick lookups.
