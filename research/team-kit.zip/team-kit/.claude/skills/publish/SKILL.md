---
name: publish
description: Publish edited shared docs so every teammate's agent gets them - in docs-mode B, pushes them to the context branch (run after ANY shared-doc edit, same turn); in docs-mode A, commits them to main like any code change. Use when the user says "publish this", "push the docs". Mode B refuses to clobber newer teammate edits, non-owners editing others' briefs, and credential-shaped content.
argument-hint: "\"what changed, in plain words\""
allowed-tools: Bash(scripts/publish-context.sh *), Bash(git *), Read, Edit
---

# Publish shared docs

```!
cd "$CLAUDE_PROJECT_DIR" && git config --get team.context-branch 2>/dev/null || echo "MODE_A"
```

$ARGUMENTS

## Docs-mode A (pre-run printed MODE_A)

Shared docs are ordinary repo files: stage and commit them to `main` (or the feature branch)
with a plain message, per the normal ship sequence. The guard hook is inert in this mode. Done.

## Docs-mode B (a branch name printed)

1. If `git config --get team.builder` is empty: stop; the user sets it once per clone
   (START-HERE step 1), then continue.
2. Run `bash scripts/publish-context.sh "$ARGUMENTS"` (the user's own words for the message).
3. **Success** (prints `context: published <sha>`): one line to the user is enough.
4. **Refused** — follow the printed reason:
   - *changed on context since your last sync AND locally* → run the `sync` skill (it saves the
     local copy to `.git/context-backup/`), re-apply the edit keeping **every** incoming line,
     publish again.
   - *only the doc owner publishes <file>* → the edit belongs to PROJECT.md §Doc owner. Unless
     the current user is that person: revert the local edit (or move it to a note) and route it
     via a `BOARD.md` 📨 ping.
   - *looks like a credential* → a real secret must never be published; take it out. A false
     positive: reword so it no longer matches the shape of a secret.
5. Never force, never switch branches, never commit these files to `main` (the guard blocks it).

Self-edit rule: everyone may publish exactly one shared doc — moving their own finished task
into the Archived section of their own `builder-file-<name>.md`. Everything else goes to the doc
owner.
