---
name: score
description: Run a fresh-context scorer loop that grades a deliverable against a rubric and iterates until it passes - use for any important deliverable (a feature diff, a document, a pitch, a report, a refactor) that must clear a quality bar before it counts as done, when the user says "score this", "grade this", "quality gate", "don't let it pass until...", or before handing off work to a teammate or submitting anything. The scorer's verdict is a gate, not advice.
argument-hint: "<what to score> [rubric file, default docs/RUBRIC.md]"
---

# Score — generate → grade → revise, until the gate opens

An artifact is not done because its author says so. A fresh-context grader — one that cannot see
the author's reasoning, only the artifact, the criteria and the deterministic evidence — decides.
This skill runs that loop.

## 1. Fix the inputs

- **Artifact:** $ARGUMENTS. For a diff, capture it first (`git diff` + untracked files) into a
  temp file so the grader sees exactly what would ship.
- **Rubric:** the named file, else `docs/RUBRIC.md`; for documents/pitches, build the rubric from
  the acceptance criteria first (a deliverable without checkable criteria cannot be gated).
- **Deterministic evidence:** run the machine checks first (tests, build, lint) and feed the
  **exit codes and tails** to the grader. Machine checks come before model judgment; the rubric
  governs only what code can't check. A deliverable with red deterministic gates is auto-FAIL —
  don't even dispatch.
- **Context the grader needs:** stated intent, audience, hard constraints. No author reasoning.

## 2. Dispatch the grader

Spawn the `scorer` subagent with artifact + rubric + deterministic evidence + context. The
grader critiques per criterion **before** verdicting, cites evidence that **must exist verbatim
in the artifact** (a quoted span that doesn't string-match = failed criterion + flagged as
hallucinated evidence), and returns JSON: `PASS` / `FAIL` / `UNKNOWN`, per-criterion results,
actionable gaps on FAIL. If the host allows choosing the subagent's model, prefer a different
model family than the session's — same-family self-grading adds the least signal.

## 3. The loop

- `PASS` → done. Report the verdict and the strongest residual notes.
- `FAIL` → fix **only the cited gaps**, then re-grade everything from scratch (fresh grader run).
- `UNKNOWN` → supply the missing evidence; don't argue.
- **Hard caps:** 3 revision rounds; **and** an early stop if the same top gap persists two rounds
  running (non-convergence — the task or rubric is wrong). At either cap: stop, show the human
  the verdicts and remaining gaps, let them decide. Also watch spend: if the grader's rounds are
  burning budget out of proportion to the deliverable, stop and say so.

## Rules that keep the gate honest

- Never grade your own work in-context; fresh eyes are the entire value.
- Never soften a FAIL. The only path to PASS is fixing the artifact.
- Never edit the rubric mid-loop to make it pass; rubric changes are the human's call (`decide`)
  and restart the loop from round 1.
- Never weaken tests/checks to open the gate — that's tampering (AGENTS.md non-negotiables).
- Report the final verdict verbatim in the BOARD.md entry when this gate guards a ship.
