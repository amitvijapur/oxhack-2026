---
name: signoff
description: End-of-session wrap-up that saves state so the next session (or a teammate) can resume exactly where this one stopped - run when the user says "signing off", "wrapping up", "I have to go", "call it a night", "closing the terminal". Saves cross-session memory, de-stales every mirror doc, publishes pending doc edits, and leaves a START HERE pointer.
---

# Sign-off

Nothing important dies with the session. Work through this list, then confirm in one short block
what was saved and where.

1. **Unfinished gate?** If a ship is mid-loop (scorer FAIL pending fixes, tests red), either
   finish the round or leave the work unmerged with a note — never merge to "close the session".
2. **Unpublished shared-doc edits** — the Stop hook flags them; publish per PROJECT.md §Docs
   mode now, or the next teammate's sync misses them (docs-mode B).
3. **Save state** — durable facts to the project memory: decisions disposed, decisions pending
   (unconfirmed + revisit condition), open threads, and the exact next step. Preserve every
   important detail; depth wins over token economy here.
4. **De-stale every mirror** — propagate what this session changed to every doc that references
   it: `BOARD.md` (entries for anything completed but unlogged; **Current state** block),
   `PROJECT.md` (ownership/commands/gotchas that changed), `DECISIONS.md` (new decisions),
   briefs (finished tasks ✅). Resolve disagreements to the newest state; superseded items move
   to Archive with the reason — never deleted.
5. **Leave a START HERE pointer** — the half-done task and its precise spot ("`fn X` in `file
   Y`, retry-path tests missing") or the next-highest item; top of the memory status block.
6. **Remind the user** of open *Unconfirmed / yet-to-confirm* decisions — name them.
7. **Loose ends needing a human** (an approval only they can give, a deploy, a secret rotation):
   route them now via a BOARD.md `📨 To <Name>` line — not into memory only.
