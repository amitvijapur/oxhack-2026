# DECISIONS — lightweight ADR log (append-only)

One entry per disposed decision. "Unconfirmed" items are leanings, never agreed work — offer them
when nothing active remains. Attribute by person; unnamed → (owner: TBC); never invent an owner.
Decisions listed in PROJECT.md §Locked decisions need the team's named agreement to reopen.

```
## <date> — <decision name>
- Chose: <option> (<who decided>)
- Because: <one line>
- Rejected: <alternatives + why not>
- Revisit if: <the condition that would change this>
```

## Unconfirmed / yet-to-confirm
<!-- parked leanings and "later maybe" options with their revisit conditions; not agreed work -->

- (none)
