# Team Workflow — Agent Contract (universal)

This file is the **workflow contract**: the rules that hold on every prompt, for every coding agent
on this repo, regardless of vendor. Project-specific facts (stack, commands, owners, deploy) live
in `PROJECT.md` — read it before doing anything. This file changes rarely; `PROJECT.md` changes
often. If a rule here and `PROJECT.md` ever disagree on *process*, this file wins; tell the doc
owner. If they disagree on *facts*, `PROJECT.md` wins; it's the source of truth for facts.

## Non-negotiables (hook- or CI-enforced; prose here is only the explanation)

- **Never commit or stage secrets.** The repo may be public; a pushed secret is public forever.
- **Never modify the verification machinery to pass it** — no deleting/weakening tests, no editing
  the scorer agent, rubric, or hooks to make a gate open. Fix the work instead.
- **Shared docs publish through the sanctioned path only** (see PROJECT.md §Docs mode). The
  PreToolUse hook blocks the git shortcuts.
- **No AI attribution on commits** — they are the author's own work. The commit-msg hook rejects
  trailers.

## The one rule — the human owns every design decision; the agent owns the typing

A *design decision* is any choice a real engineer would pause on — the shape, not the syntax. When
a task contains one, **stop and hand it over** (skill: `decide`); never pick silently. The agent
proposes options with a recommendation; the human disposes; the choice is logged as theirs.

**Always the human's call:** data & storage · API/contract shapes · trust & access boundaries ·
where computation runs · failure modes and anything safety-critical · adding any dependency ·
correctness/speed/cost trade-offs · anything PROJECT.md marks as locked.

**Agent may just do it** (say what and why, one line): bugs with one correct answer ·
zero-behaviour refactors · implementing a decision already made · tests for existing behaviour ·
formatting and quality cleanups. **Unsure which bucket → hand off.** Silent choices are the
failure mode this contract exists to prevent.

## The loop (per feature, in order)

1. **Orient.** Check `BOARD.md` for entries newer than your last look (skill: `conflicts`). Any
   open conflict naming the current human → surface it first, resolve before touching that area.
2. **Plan before code.** For anything bigger than a one-line fix, write a short plan (what will
   change, files touched, how it'll be tested) and get a human nod — plan mode where available.
   A gate before work is cheaper than a gate after it.
3. **Decide.** Design decisions go through `decide`; the human picks; log to `DECISIONS.md`.
4. **Ship** (skill: `ship`): quality pass → tests with coverage → **deterministic gates green**
   (build/test/lint exit codes) → **fresh-context scorer PASS** (skill: `score`) → push branch →
   merge main + retest → merge to main → `BOARD.md` entry. One feature per ship.
5. **Log and publish.** Every completed task gets a `BOARD.md` entry (format below). Doc edits
   publish the same turn per PROJECT.md §Docs mode.

Stuck after two attempts, any error, flaky test, surprise output → the `debug` skill (or your
platform's equivalent evidence-first procedure). No guess-and-retry outside it.

## BOARD.md — the append-only ship log and conflict board

Every completed task (feature, fix, deploy, decision that changes work) gets one entry, appended,
pushed to main in the same turn:

```
### <YYYY-MM-DD HH:MM> — <feature> — @<owner>
- Shipped: <what changed, why>
- Touched: <files / modules / endpoints / shared contracts>
- ⚠️ Conflicts: @<Name> — <what of theirs this changes or could break> | none
- Conflict status: open | resolved by @<Name> <date>
```

Before starting work: read new entries since your last check. An open ⚠️ naming the current human
is a stop sign — resolve or agree with the flagger first. Fill conflicts honestly against the
ownership table in PROJECT.md; a *possible* collision counts. Cross-person requests ("@Name needs
to do X before Y") live here or in the named brief — never only in chat. Never rewrite or delete
another person's entries; annotate or mark resolved.

## Quality gates (what "done" means)

- Nothing merges with failing tests, a failing build, or lint errors — **exit codes are the gate**.
- Nothing merges without a fresh-context scorer PASS against `docs/RUBRIC.md` (skill: `score`).
  The scorer sees only the artifact, the rubric and the stated intent — never the author's
  reasoning. Its evidence must be machine-checkable (quoted spans that exist in the artifact,
  real command output). Its verdict is a gate, not an opinion; the only path to PASS is fixing
  the work. Max 3 revision rounds, then escalate to the human.
- Code quality pass (`no-slop` skill or equivalent) before every commit: no dead code, no
  what-comments, no duplicated logic, no over-defensive checks, right complexity class.
- Comments say **why**, never what. No comment beats a what-comment.

## Parallel work

Two agents in one checkout is data loss (silent last-write-wins). One agent per checkout — use
worktrees/branches per session or per person (e.g. `claude --worktree <name>`), short-lived
branches, merge main in frequently. Shared resources (a dev database, ports): one person at a
time or per-worktree instances.

## Documentation

Short sentences, plain words, skimmable — a tired teammate gets the point in one read. A fact
that lives in several places updates in **all** of them the moment it changes; a stale mirror is
a bug: resolve to the newest, move superseded items to an Archive block with the reason, never
delete. Volatile facts (test counts, current deploy state) live in exactly one place —
`BOARD.md` → Current state — and everything else points there. Could a future session reconstruct
the decision from this note alone? If not, add context; if bloated, tighten prose.

## Rules that grow

Add a rule only after an observed agent failure, one sentence, tied to that failure
(fail-driven, not preemptive — preemptive rules are reliably ignored). When a failure repeats,
prefer a hook or CI check over prose: **prose is a suggestion; a hook is a wall.**

## Ask, don't assume

When the human's answer would settle something genuinely unclear (scope, intent, a fact not in
the repo), ask, stating the assumption you'd otherwise make. Exception: obvious low-stakes
defaults — state the default, proceed, say so.

## Session end

On "signing off / wrapping up": run the `signoff` skill — save state to memory, publish pending
doc edits, de-stale every mirror, leave a START HERE pointer naming the exact next step. Never
drop important detail to save tokens; depth wins when it matters.
