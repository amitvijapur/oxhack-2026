#!/bin/bash
# Initialize (or verify) this team-workflow kit inside a repository. Idempotent: copies only
# files that don't already exist, never overwrites, never deletes. Ends with the doctor: a count
# of unfilled FILL slots — the kit is "ready" when PROJECT.md has zero (TBC slots may remain).
# Usage: bash /path/to/team-kit/scripts/init-kit.sh [repo-root]   (default: cwd's git toplevel)
set -euo pipefail
src=$(cd "$(dirname "$0")/.." && pwd)
dst=${1:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}
cd "$dst"

copy_if_absent() { # <src> <dst>
  if [ -e "$2" ]; then
    echo "keep   existing $2"
  else
    mkdir -p "$(dirname "$2")"
    cp "$1" "$2"
    echo "add    $2"
  fi
}

echo "== installing kit into $dst =="
for f in AGENTS.md CLAUDE.md PROJECT.md BOARD.md DECISIONS.md START-HERE.md; do
  copy_if_absent "$src/$f" "$f"
done
mkdir -p .claude/skills .claude/agents .claude/hooks docs scripts
for f in "$src"/.claude/hooks/*; do copy_if_absent "$f" ".claude/hooks/$(basename "$f")"; done
for f in "$src"/.claude/agents/*; do copy_if_absent "$f" ".claude/agents/$(basename "$f")"; done
for d in "$src"/.claude/skills/*/; do
  name=$(basename "$d")
  if [ -e ".claude/skills/$name" ]; then echo "keep   existing .claude/skills/$name"; else cp -r "$d" ".claude/skills/$name"; echo "add    .claude/skills/$name"; fi
done
for f in "$src"/docs/*; do copy_if_absent "$f" "docs/$(basename "$f")"; done
# optional context-branch module (docs-mode B machinery) + shared settings, if absent
if [ ! -e .claude/settings.json ] && [ -e "$src/.claude/settings.json" ]; then
  copy_if_absent "$src/.claude/settings.json" ".claude/settings.json"
fi
for f in sync-context.sh publish-context.sh test-context-scripts.sh context-docs.list; do
  copy_if_absent "$src/scripts/$f" "scripts/$f"
done
mkdir -p scripts/git-hooks
for f in "$src"/scripts/git-hooks/*; do copy_if_absent "$f" "scripts/git-hooks/$(basename "$f")"; done

# docs-mode B needs shared docs ignored on main; ship the block commented so mode A is unaffected
if ! grep -q "team-kit docs-mode B" .gitignore 2>/dev/null; then
  {
    printf '
# team-kit docs-mode B (context branch): uncomment these in mode B so shared docs
'
    printf '# can never be staged on main; the PreToolUse guard blocks named adds either way
'
    printf '#CLAUDE.md
#AGENTS.md
#PROJECT.md
#BOARD.md
#DECISIONS.md
#START-HERE.md
#CONTEXT-README.md
#builder-file-*.md
#.claude/
'
  } >> .gitignore
  echo "add    .gitignore (commented docs-mode B block)"
fi

echo
echo "== doctor: unfilled slots =="
n=$(grep -rn "FILL" PROJECT.md START-HERE.md BOARD.md 2>/dev/null | wc -l | tr -d ' ')
if [ "$n" = "0" ]; then
  echo "ready: no FILL markers left. Enable the git hooks: git config core.hooksPath scripts/git-hooks"
else
  echo "$n unfilled slot(s) — a human fills these (the 'onboard' skill can draft; approval required):"
  grep -rn "FILL" PROJECT.md START-HERE.md BOARD.md 2>/dev/null | sed 's/^/  /'
  echo "kit installed, but work needing these facts waits until they're filled."
fi
