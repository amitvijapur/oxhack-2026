#!/bin/bash
# Pull the latest shared docs from the team's `context` branch into this folder. Files are unpacked,
# never staged: main's .gitignore ignores them, so they can't be committed by accident. A doc you
# edited but haven't published is copied to .git/context-backup/ before it's replaced, so no edit
# is lost. Prints what changed since the last sync so the agent can tell the user before working.
# The tracked set is whatever lives on the branch — this script needs no doc list.
# No-op (one line) when the repo doesn't use a context branch: no origin/<branch> ref, where the
# branch name is `git config team.context-branch` or `context` by default.
set -euo pipefail
# Git Bash on Windows rewrites "rev:.claude/..." arguments as Windows paths unless this is set
export MSYS_NO_PATHCONV=1
cd "$(git rev-parse --show-toplevel)"
branch=$(git config --get team.context-branch || echo context)
if ! git ls-remote --exit-code --heads origin "$branch" >/dev/null 2>&1; then
  echo "context: no '$branch' branch — shared docs are committed in-repo; nothing to sync"
  exit 0
fi
git fetch -q origin "$branch"
new=$(git rev-parse "origin/$branch")
gitdir=$(git rev-parse --git-dir)
stamp="$gitdir/context-synced"
old=$(cat "$stamp" 2>/dev/null || echo none)
if [ "$new" = "$old" ]; then
  echo "context: up to date (${new:0:7})"
  exit 0
fi

if [ "$old" != none ] && git cat-file -e "$old^{commit}" 2>/dev/null; then
  incoming=$(git diff --name-only --diff-filter=d "$old" "$new")
else
  incoming=$(git ls-tree -r --name-only "$new")
fi
backup="$gitdir/context-backup/$(date +%Y%m%d-%H%M%S)"
saved=()
while IFS= read -r f; do
  [ -n "$f" ] || continue
  latest=$(git rev-parse "$new:$f")
  if [ -f "$f" ]; then
    mine=$(git hash-object "$f")
    [ "$mine" = "$latest" ] && continue
    base=$(git rev-parse -q --verify "$old:$f" 2>/dev/null || echo none)
    if [ "$mine" != "$base" ]; then
      mkdir -p "$backup/$(dirname "$f")"
      cp "$f" "$backup/$f"
      saved+=("$f")
    fi
  fi
  mkdir -p "$(dirname "$f")"
  git cat-file blob "$latest" > "$f"
done <<< "$incoming"
echo "$new" > "$stamp"

if [ "$old" = none ]; then
  echo "context: first sync at ${new:0:7}. Read PROJECT.md (NOW) and your builder-file-<name>.md."
else
  echo "context: UPDATED ${old:0:7} -> ${new:0:7}"
  git log --format='  %h %s (%an, %ar)' "$old..$new"
  git diff --stat "$old" "$new" | tail -n +1
fi
if [ ${#saved[@]} -gt 0 ]; then
  echo "context: you had unpublished edits, saved in $backup. Re-apply them, then publish:"
  printf '  %s\n' "${saved[@]}"
fi
