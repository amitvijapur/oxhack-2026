#!/bin/bash
# Runs sync-context.sh and publish-context.sh against a throwaway remote, with names nothing like
# the repo this kit came from (proving the scripts are project-agnostic): a stale copy must never
# undo a teammate's published edit, teammates may publish only their own brief, new docs listed in
# context-docs.list publish on first add, sync must never lose an unpublished local edit, and a
# repo without the branch degrades to a no-op. Usage: bash scripts/test-context-scripts.sh
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
fail() { echo "FAIL: $*" >&2; exit 1; }
quiet() { "$@" >/dev/null 2>&1; }
# MSYS_NO_PATHCONV only around `git show`: elsewhere Git Bash must still translate the /tmp paths for Windows git
on_context() { (cd "$tmp/$1" && git fetch -q origin ctx && MSYS_NO_PATHCONV=1 git show "origin/ctx:$2"); }

git init -q --bare "$tmp/remote.git"
git init -q "$tmp/seed"
cd "$tmp/seed"
git config user.email seed@test
git config user.name seed
git checkout -q -b main
mkdir scripts
cp "$here/sync-context.sh" "$here/publish-context.sh" "$here/context-docs.list" scripts/
printf '* text=auto eol=lf\n' > .gitattributes
printf '*.md\n.claude/\n' > .gitignore
git add .
git commit -qm main
git remote add origin "$tmp/remote.git"
git push -q origin main
# the team's context branch, with a custom name to prove it isn't hardcoded
git checkout -q --orphan ctx
git rm -rq --cached .
rm -rf scripts .gitignore
mkdir -p .claude/skills/demo
for f in CONTEXT-README.md CLAUDE.md TEAM-WORKFLOW.md PROJECT.md EVENT-CONTEXT.md \
         builder-file-alice.md builder-file-bob.md .claude/skills/demo/SKILL.md; do
  echo "$f v1" > "$f"
done
git add -f .
git commit -qm docs
git push -q origin ctx

for who in alice bob carol; do
  git clone -q -b main "$tmp/remote.git" "$tmp/$who"
  git -C "$tmp/$who" config user.email "$who@test"
  git -C "$tmp/$who" config user.name "$who"
  git -C "$tmp/$who" config team.builder "$who"
  git -C "$tmp/$who" config team.doc-owner alice
  git -C "$tmp/$who" config team.context-branch ctx
  (cd "$tmp/$who" && quiet bash scripts/sync-context.sh)
done

# a stale copy must never undo a teammate's newer publish (the bug this once was)
cd "$tmp/bob"
echo "bob: task 3 done" >> builder-file-bob.md
quiet bash scripts/publish-context.sh "bob done" || fail "bob could not publish his own brief"
cd "$tmp/carol"
echo "carol: task 6 done" >> builder-file-carol.md 2>/dev/null || cp builder-file-bob.md builder-file-carol.md
quiet bash scripts/publish-context.sh "carol done" || fail "carol could not publish her own brief (new doc via context-docs.list)"
on_context carol builder-file-bob.md | grep -q "task 3 done" || fail "carol's stale copy undid bob's edit"

# a skill added on context after bob's last sync survives carol's next publish
cd "$tmp/alice"
quiet bash scripts/sync-context.sh
mkdir -p .claude/skills/added
echo "new skill" > .claude/skills/added/SKILL.md
quiet bash scripts/publish-context.sh "alice adds a skill" || fail "alice could not add a skill"
cd "$tmp/bob"
echo "bob: task 4 done" >> builder-file-bob.md
quiet bash scripts/publish-context.sh "bob again" || fail "bob's second publish failed"
on_context bob .claude/skills/added/SKILL.md | grep -q "new skill" || fail "bob's publish dropped a skill added after his sync"

# teammates can't publish someone else's brief or shared docs; the doc owner can publish several
cd "$tmp/carol"
quiet bash scripts/sync-context.sh
echo "carol edits bob" >> builder-file-bob.md
quiet bash scripts/publish-context.sh "x" && fail "carol published bob's brief"
on_context carol builder-file-bob.md > builder-file-bob.md
echo "carol edits the rules" >> CLAUDE.md
quiet bash scripts/publish-context.sh "x" && fail "carol published CLAUDE.md"
on_context carol CLAUDE.md > CLAUDE.md
cd "$tmp/alice"
quiet bash scripts/sync-context.sh
echo "alice tidies" >> builder-file-bob.md
echo "alice tidies" >> builder-file-carol.md
quiet bash scripts/publish-context.sh "alice tidies two briefs" || fail "the doc owner could not publish two briefs"

# publishing without saying who you are is refused
cd "$tmp/carol"
git config --unset team.builder
quiet bash scripts/sync-context.sh
echo "x" >> builder-file-carol.md
quiet bash scripts/publish-context.sh "x" && fail "publish ran without team.builder"
git config team.builder carol
on_context carol builder-file-carol.md > builder-file-carol.md

# bob's last sync predates alice's tidy of his brief: publishing is refused, and sync keeps his edit as a backup
cd "$tmp/bob"
echo "bob: unpublished note" >> builder-file-bob.md
quiet bash scripts/publish-context.sh "conflict" && fail "publish ignored a change made on both sides"
quiet bash scripts/sync-context.sh
grep -rq "unpublished note" .git/context-backup || fail "sync lost bob's unpublished edit"
grep -q "alice tidies" builder-file-bob.md || fail "sync didn't bring in alice's tidy"

# a repo with no context branch: sync is a clean no-op, publish refuses with a clear error
git init -q "$tmp/plain"
cd "$tmp/plain"
git config user.email p@p; git config user.name p; git commit -q --allow-empty -m x
out=$(bash "$here/sync-context.sh" || true)
echo "$out" | grep -q "nothing to sync" || fail "no-branch repo didn't no-op cleanly: $out"

echo "PASS: context scripts"
